#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.15"
/* generated using gnu compiler gcc (Ubuntu 7.4.0-1ubuntu1~18.04) 7.4.0 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
