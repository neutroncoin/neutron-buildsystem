#ifndef _ISL_INCLUDE_ISL_STDINT_H
#define _ISL_INCLUDE_ISL_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "isl 0.15"
/* generated using gnu compiler gcc (Debian 6.3.0-18+deb9u1) 6.3.0 20170516 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
