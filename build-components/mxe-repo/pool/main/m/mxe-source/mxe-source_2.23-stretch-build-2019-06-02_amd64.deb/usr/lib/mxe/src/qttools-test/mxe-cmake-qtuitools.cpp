// This file is part of MXE. See LICENSE.md for licensing information.

// Source: https://github.com/mxe/mxe/issues/1185

#include <QUiLoader>

int main() {
    QUiLoader l;
    return 0;
}
