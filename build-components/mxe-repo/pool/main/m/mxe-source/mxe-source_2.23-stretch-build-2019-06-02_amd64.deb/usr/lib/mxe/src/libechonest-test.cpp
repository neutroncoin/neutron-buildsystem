#include <echonest/Song.h>

int main()
{
    Echonest::Song a;
    return 0;
}
