# Notes about GCC version 4.9.4

GCC 4.9.4 was used before [GCC 5.4.0](https://github.com/mxe/mxe/pull/1541).
This plugin is a backup in case of problems with GCC 5.4.0.
